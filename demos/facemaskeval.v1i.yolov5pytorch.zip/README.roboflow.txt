
facemaskeval - v1 2022-04-07 9:37pm
==============================

This dataset was exported via roboflow.ai on April 7, 2022 at 7:37 PM GMT

It includes 56 images.
Faces-masks are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


